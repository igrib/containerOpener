*About This Extension*
This extension lets you open up a site in multiple containers at the same time. Why would someone want this? Well, if you have multiple email-accounts with one provider you can create containers for each account (using Firefox Multi-Account Containers plugin) and then open them all up at once. This makes it easy to check multiple accounts at the same time.



