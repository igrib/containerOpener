#v1.5
* Cleaned up CSS

#v1.6
* Allow URLs with special characters
* Fix issue deleting URLs with special characters
* Added feature to open current site in all sessions

#v1.7 
* Added clear button to clear all site. This is needed to fix an issue with updating from v1.5 to v1.6

#v1.8
* Added display name that can be set instead of showing just the URL.
* Added some colors and styling

#v1.9
* Improved checking of valid URLs to be more permissive

#v1.10
* Fixed bug with columns being misaligned by one. Thank you Ya Zahra
